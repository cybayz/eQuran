<?php

require_once "../app/init.php";

$App = new App\Core\App;
$App->run();
